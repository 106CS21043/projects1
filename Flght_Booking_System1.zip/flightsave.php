<html>
    <body>
        <?php
        $fname=$_POST['f_name'];
        $fno=$_POST['f_no'];
        $ftype=$_POST['f_type'];
       
      
        
        $con=mysql_connect("localhost","root","");
        mysql_select_db("flight",$con);
        mysql_query("insert into flights values('$fname','$fno','$ftype')");
     
        echo"<br><center><b>New flight &nbsp $fname Added Successful....!";
?>
<a href="adminmain.html">home</a>
    </body>
    </html>