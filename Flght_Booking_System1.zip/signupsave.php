<html>
    <body>
        <?php
        $uname=$_POST['uname'];
      
        $email=$_POST['mail'];
        $pass=$_POST['pass'];
        
        
        
        $con=mysql_connect("localhost","root","");
        mysql_select_db("flight",$con);
        mysql_query("insert into signup values('$uname','$email','$pass')");
            echo"<br><center><b>New User &nbsp $uname Added Successful....!";
?>
        
</body>
</html>
