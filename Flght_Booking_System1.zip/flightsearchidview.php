<html>
<body>
<center><h1> Flights Available</h1><hr>
<?php
$fno=$_POST['f_no'];
$con=mysql_connect("localhost","root","");
mysql_select_db("flight",$con);
$records=mysql_query("select * from flights where f_no='$fno'");

if($row=mysql_fetch_array($records))
{
    ?>


<table border=2>
<tr><th>Flight Name</th><th>Flight No</th><<th>Flight-Type</th></tr>
<?php

    echo "<tr><td>".$row[0]."</td><td>".$row[1]."</td><td>".$row[2]."</td></tr>";
}
else{
    echo"<br> <center> Flight not Found of ID:'$fno'"; 
}
?>

</body>
</html>
