<html>
    <body>
        <?php
     $fid=$_POST['fid'];
     $fsrc=$_POST['fsrc'];
     $fdstn=$_POST['fdstn'];
     $date=$_POST['date'];
     $departtime=$_POST['departtime'];
     $arrivaltime=$_POST['arrivaltime'];
     $fduration=$_POST['fduration'];
     $fseats=$_POST['fseats'];
     $bookedseats=$_POST['bookedseats'];
     $availableseats=$_POST['availableseats'];
     $fprice=$_POST['fprice'];
        $con=mysql_connect("localhost","root","");
        mysql_select_db("flight",$con);
        mysql_query("insert into routes values('$fid','$fsrc','$fdstn','$date','$departtime','$arrivaltime','$fduration','$fseats','$bookedseats','$availableseats','$fprice')");
        echo"<br><center><b>New route &nbsp $fid Added Successful....!";
        
?>
<a href="adminmain.html">home</a>
    </body>
    </html>
