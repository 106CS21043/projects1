<html>
    <body>
    <?php
    $emailid = $_POST['id'];
    $pass = $_POST['pass'];
    $message = "";

    // Establishing connection
    $con = mysqli_connect("localhost", "root", "", "flight");

    // Checking connection
    if (mysqli_connect_errno()) {
        echo "Failed to connect to MySQL: " . mysqli_connect_error();
        exit();


    // Avoiding SQL Injection using prepared statements
    $stmt = $con->prepare("SELECT * FROM signup WHERE email=? AND password=?");
    $stmt->bind_param("ss", $emailid, $pass);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 1) {
        // User logged in successfully
        header("Location: usermain.html");
        $message = "$emailid logged in successfully........!";
        exit();
    } elseif ($pass === "12345" && $emailid === "admin") {
        // Admin logged in successfully
        header("Location: adminmain.html");
        $message = "Admin logged in successfully........!";
        exit();
    } elseif (empty($emailid)) {
        $message = "Please Enter Email";
    } elseif (empty($pass)) {
        $message = "Please Enter Password";
    } else {
        $message = "Invalid Email or Password";
    }

    // Displaying message using JavaScript alert
    echo "<script>alert('$message');</script>";

    // Closing connection
    mysqli_close($con);
    ?>
    </body>
</html>
