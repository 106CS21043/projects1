<html>

<body>
   <?php
include('usercontent.php');
   ?>
    <div class="border"  style="height:auto;">
    <form method="post" action="flightsrcdstnsearch.php">

      
<div class="input1">
<h2>From:<br>
<input type="text" style="width:250px" name="fromcity" >
</div>
      
<div class="input2">
    <h2>To:<br>
    <input type="text" style="width:250px" name="tocity" >
    </div>
<div class="input3">
<h2>Date:<br>
<input type="date" style="width:250px" name="date" >
</div>

<div class="input5">
<h2>Class: <br>
<select name="fClass" id="class" style="width:250px;"required>
<option>Economy</option>
<option>Premium Economy</option>
<option>Business</option>
<option>First Class</option>    
</select> 
</div>



<input type="submit" value="Search Flights"   style="padding-left: 100px;
    top:700px;
    background-color: #4CAF50; 
    border: none;
    color: white; 
    padding: 10px 20px; 
    text-align: center; 
    text-decoration: none; 
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
    cursor: pointer;
    border-radius: 5px;">


</form>
</div>
</body>
</html>
