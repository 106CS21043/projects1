<html>
<body>

<?php

$con=mysql_connect("localhost","root","");
mysql_select_db("flight",$con);
$records=mysql_query("select * from flights ");


    ?>
<center><h1> Flights Available</h1><hr>
<table border=2>
<tr><th>Flight Name</th><th>Flight No</th><th>Flight-Type</th></tr>
<?php
while($row=mysql_fetch_array($records)){


    echo "<tr><td>".$row[0]."</td><td>".$row[1]."</td><td>".$row[2]."</td></tr>";
}
?>
</body>
</html>
