<?php
  $fid = $_POST['f_id'];
  $noofpass=$_POST['noofpassengers'];

  $con = mysql_connect("localhost", "root", "");
  mysql_select_db("flight", $con);
  $records =mysql_query("SELECT f_seats,booked_seats,available_seats FROM routes  where f_id='$fid'");
  while($row = mysql_fetch_array($records)) { 
    $fseats= $row[f_seats];
    $bookedseats=$row[booked_seats];
    $availableseats=$row[available_seats];



 mysql_query("Delete from bookings  where f_id='$fid' ");
  

 $n=$bookedseats-$noofpass;
 $t = $fseats - $n;
 mysql_query("update routes set booked_seats='$n',available_seats='$t' where f_id='$fid'");


  }
  
 
echo "<br>Bookings canceled successfully... $fid ";
?>