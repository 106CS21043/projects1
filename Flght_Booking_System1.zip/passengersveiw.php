<html>
    <body>
        <?php
        $con = mysql_connect("localhost", "root", "");
        mysql_select_db("flight", $con);
        $records = mysql_query("SELECT * FROM passenger");

        ?>
        <table border="2">
            <tr>
                <th>p_name</th>
                <th>password_id</th>
                <th>Nationality</th>
                <th>p_gender</th>
                <th>pdob</th>
                <th>p_age</th>
                <th>p_email</th>
                <th>phone_no</th>
                <th>p_address</th>
                <th>p_image</th>
            </tr>
            <?php
                    while ($row = mysql_fetch_array($records)) {
       
                echo "<tr><td>".$row[0]."</td><td>".$row[1]."</td><td>".$row[2]."</td><td>".$row[3]."</td><td>".$row[4]."</td><td>".$row[5]."</td><td>".$row[6]."</td><td>".$row[7]."</td><td>".$row[8]."</td><td>" ?> <img src= <?php echo $row["p_image"]?>  alt='Passenger Image' width=100px height=100px ><?php "</td></tr>";
            }
            ?>
        </table>
    </body>
</html>