<html>
<body>
<?php
$ename=$_POST['emp_name'];
$eid=$_POST['emp_id'];
$edob=$_POST['emp_dob'];
$egender=$_POST['emp_gender'];
$ejob=$_POST['emp_job'];
$esal=$_POST['emp_sal'];
$eadd=$_POST['emp_address'];
$emob=$_POST['emp_mob'];
$con=mysql_connect("localhost","root","");
mysql_select_db("flight",$con);
mysql_query("Update employee set emp_name='$ename',emp_dob='$edob',emp_gender='$egender',emp_job='$ejob',emp_sal='$esal',emp_address='$eadd',emp_mob='$emob' where emp_id='$eid'");
echo "<br> new employee records updated successfully...";
?>
<br><br>
<a href="adminmain.html">Home</a>
</body>
</html>