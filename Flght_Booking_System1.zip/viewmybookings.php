<html>
    <body><center>
        
        <?php
    
        
        $con = mysql_connect("localhost", "root", "");
        mysql_select_db("flight", $con);
        
        $records = mysql_query("SELECT * FROM bookings");
        
        if(mysql_num_rows($records) > 0) {
            ?>
            <table border="2">
                <tr>
                <th>f_id</th><th>source</th><th>destination</th><th>date</th><th>price</th>
                    <th>name</th><th>passport id</th><th>gender</th><th>age</th><th>NO of passengers</th><th>Booked-date</th><th>cancel-booking</th>
                </tr>
                <?php
                while($row = mysql_fetch_array($records)) { 
                    echo "<tr>";
                    echo "<td>".$row[0]."</td><td>".$row[1]."</td><td>".$row[2]."</td><td>".$row[3]."</td><td>".$row[4]."</td><td>".$row[5]."</td><td>".$row[6]."</td><td>".$row[7]."</td><td>".$row[8]."</td><td>".$row[9]."</td><td>".$row[10]."</td>";
                    echo "<td><form method='post' action='deletemybookings.php'><input type='hidden' name='f_id' value='".$row[0]."'><input type='hidden' name='noofpassengers' value='".$row[9]."'><input type='submit' value='cancel Now'></form></td>";
                    echo "</tr>";
                }
            }
            else{
                echo"<h3> No Bookings yet</h3>";



            }
                ?>
