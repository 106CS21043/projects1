<html>
    <body>
        <?php
        $fsrc = $_POST['fromcity'];
        $fdstn = $_POST['tocity'];
        $fdate = $_POST['date'];
        
        $con = mysql_connect("localhost", "root", "");
        mysql_select_db("flight", $con);
        
        $records = mysql_query("SELECT * FROM routes WHERE source='$fsrc' OR destination='$fdstn' OR date='$fdate'");
        
        if(mysql_num_rows($records) > 0) {
            ?>
            <table border="2">
                <tr>
                    <th>f_id</th><th>source</th><th>destination</th><th>date</th><th>depart_time</th>
                    <th>arrival_time</th><th>duration</th><th>no_of_seats</th><th>booked seats</th><th> available seats</th><th>price</th><th>Action</th>
                </tr>
                <?php
                while($row = mysql_fetch_array($records)) { 
                    echo "<tr>";
                    echo "<td>".$row[0]."</td><td>".$row[1]."</td><td>".$row[2]."</td><td>".$row[3]."</td><td>".$row[4]."</td><td>".$row[5]."</td><td>".$row[6]."</td><td>".$row[7]."</td><td>".$row[8]."</td><td>".$row[9]."</td><td>".$row[10]."</td>";
                    echo "<td><form method='post' action='book_flight.php'><input type='hidden' name='f_id' value='".$row[0]."'><input type='submit' value='Book Now'></form></td>";
                    echo "</tr>";
                }
                ?>
            </table>
            <?php
        } else {
            echo "No flights found";
        }
        ?>
        <a href="usermain.html">Home</a>
    </body>
</html>