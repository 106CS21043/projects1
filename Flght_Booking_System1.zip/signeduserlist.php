<html>
<body>
<center><h1> USERS LIST</h1><hr>
<?php
$con=mysql_connect("localhost","root","");
mysql_select_db("flight",$con);
$records=mysql_query("select * from signup");


?>
<table border=2>
<tr><th>Name</th><th>E-Mail</th><th>Password</th></tr>
<?php
while($row=mysql_fetch_array($records)){


    echo "<tr><td>".$row[0]."</td><td>".$row[1]."</td><td>".$row[2]."</td></tr>";
}
?>
</body>
</html>