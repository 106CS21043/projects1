<html>

    <style>
        
        table{
    border:3px solid rgb(210, 211, 212);
    border-radius: 10px;
    width:auto;
    height:auto;
   
    box-shadow: 0 0 30px rgb(199, 199, 230);
    padding: 20px ;
    
    font-family: 'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif;
    background-color:white;
}
th{
    border:2px solid black;
    border-radius:10px;
    background-color:powderblue;
    padding: 10px ;

}
td{
    border:2px ;
    border-radius:2px;
    background-color:lightblue;
    padding: 10px ;
}

        </style>
    <body>


        <?php
        $con=mysql_connect("localhost","root","");
        mysql_select_db("flight",$con);
        $records=mysql_query("select*from routes");
?>
 
<div class="border">
    <center>
        
<table  >

    <tr ><th>f_id</th><th>source</th><th>destination</th><th>date</th><th>depart_time</th>
    <th>arrival_time</th><th>duration</th><th>no_of_seats</th><th>booked seats</th><th> available seats</th><th>price</th></tr>
    <?php
    while($row=mysql_fetch_array($records))
    {
        echo"<tr><td>".$row[0]."</td><td>".$row[1]."</td><td>".$row[2]."</td><td>".$row[3]."</td><td>".$row[4]."</td><td>".$row[5]."</td><td>".$row[6]."</td><td>".$row[7]."</td><td>".$row[8]."</td><td>".$row[9]."</td><td>".$row[10]."</td></tr>";
    }
    ?>
    </div>
    </body>
    </html>