

<html>
<body>
<center><h2><font color=red>Search flight<hr>
<form method="post"action="flightsearchidview.php">
Enter Flight id:<input type="text" name="f_no"><br><br>
<input type="submit" value="Search Flight">
</form>
</body>
</html>