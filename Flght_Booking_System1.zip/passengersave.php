<html>
    <body>
        <?php
        $pname=$_POST['pname'];
        $passportid=$_POST['passportid'];
        $pnation=$_POST['nationality'];
        $pgender=$_POST['pgender'];
        $pdob=$_POST['pdob'];
        $page=$_POST['age'];
        $pemail=$_POST['pemail'];
        $phoneno=$_POST['phoneno'];
        $padd=$_POST['paddress'];
        $pimage=$_POST['pimage'];
       
        
        
        $con=mysql_connect("localhost","root","");
        mysql_select_db("flight",$con);
        mysql_query("insert into passenger values('$pname','$passportid','$pnation','$pgender','$pdob','$page','$pemail','$phoneno','$padd','$pimage')");
            echo"<br><center><b>New passenger &nbsp $pname Added Successful....!";
?>
<a href="main.html">home</a>
        
</body>
</html>
