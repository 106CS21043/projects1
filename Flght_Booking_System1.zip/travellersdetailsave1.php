<?php
$fid=$_POST['fid'];
$fsrc=$_POST['fsrc'];
$fdstn=$_POST['fdstn'];
$date=$_POST['date'];
$fprice=$_POST['fprice'];
$pname=$_POST['pname'];
$fseats=$_POST['fseats'];
$bookedseats=$_POST['bookedseats'];
 $availableseats=$_POST['availableseats'];
$passportid=$_POST['passportid'];
$pgender=$_POST['pgender'];
$page=$_POST['age'];
$email=$_POST['pemail'];
$dot=date('d/m/y');
$noofpass=$_POST['noofpass'];

$con=mysql_connect("localhost","root","");
mysql_select_db("flight",$con);

        mysql_query("insert into bookings values('$fid','$fsrc','$fdstn','$date','$fprice','$pname','$passportid','$pgender','$page','$noofpass','$dot')");
        echo "<script>alert('New Booking for $pname Added Successfully!');</script>";
       
        $n=$bookedseats + $noofpass;
        $t =  $fseats - $n;
        mysql_query("update routes set booked_seats='$n',available_seats='$t' where f_id='$fid'");

?>