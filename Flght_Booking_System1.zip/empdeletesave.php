<html>
<body>
<?php
$eid=$_POST['emp_id'];
$con=mysql_connect("localhost","root","");
mysql_select_db("flight",$con);
mysql_query("Delete from employee  where emp_id='$eid'");
echo "<br>Employee records deleted successfully...";
?>
<br><br>
<a href="adminmain.html">Home</a>
</body>
</html>