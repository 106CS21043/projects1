<html>
    <head>
    
    
</head>
    <body>
        <center>
            <form name="pay">
    <h1> pay invoice</h1><hr>
     <br><br>

     <h3> capcha:s4ro2q</h3>
     <br><br>

     <h3> Enter captcha</h3>
     <br><br>
     <input type="text" name="b"   require><br>

     <input type="submit" onclick="validate();" value="verify">
     <?php
     function validate()
     {
        $n='document.pay.b.value';
        if ($Sn =="s4ro2q"){
            header("Location:travellersdetailsave1.php");
            
   

        }
        else{
            alert("please enter valid capcha");
            header("Location:payment.php");
        }
     }
     ?>
</form>