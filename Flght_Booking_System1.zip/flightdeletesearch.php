<html>
<body>
<center><h1>Delete Flight details</h1><hr>
<?php
$fno=$_POST['f_id'];
$con=mysql_connect("localhost","root","");
mysql_select_db("flight",$con);
$records=mysql_query("select * from flights where f_no='$fno'");
if($row=mysql_fetch_array($records)){
?>
<form method="post" action="flightdeletesave.php">
<table >
            <tr height="40px">
                <td >Flight Name</td>
                <td><input type="text" name="f_name" value="<?php echo $row[0];?>"></td>
            </tr>
            <tr height="40px">
                <td >Flight Number</td>
                <td><input type="text" name="f_no" readonly  value="<?php echo $row[1];?>"></td>
            </tr>
            
            <tr height="40px">
                <td > Flight TYPE</td>
                <td><select name="f_type" value="<?php echo $row[2];?>">
                    <option>commercial flight</option>
                    <option>Domestic flight</option>
                    <option>International flight</option>
                    <option>First class</option>
                    </select>
                </td>
</tr>
           <tr>
               <td> <input type="submit" value="DELETE"></td>
            </tr>
            </table>
<form>
<?php
}
else
{
echo"<br><br>No  Flights found by Id '$fid' ....";
}
?>
</body>
</html>




