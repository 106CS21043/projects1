<html>
    <body>
        <?php
        
        $fno=$_POST['f_no'];
   
      
        
        $con=mysql_connect("localhost","root","");
        mysql_select_db("flight",$con);
        mysql_query("Delete  from flights  where f_no='$fno'");   
       echo"<br><center><b> Flight &nbsp $fno Deleted  Successful....!";
?>
<a href="adminmain.html">home</a>
    </body>
    </html>