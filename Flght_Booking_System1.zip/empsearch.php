<html>
<body>
<center><h1>Search Employee</h1><hr>
<?php
$eid=$_POST['emp_id'];
$con=mysql_connect("localhost","root","");
mysql_select_db("flight",$con);
$records=mysql_query("select * from employee where emp_id='$eid'");
if($row=mysql_fetch_array($records))
{
?>
<table border=2>
<tr><th>Name</th><th>Id</th><th>DOB</th><th>Gender</th><th>JOb-Type</th><th>Salary</th><th>Address</th><th>Contact-No</th></tr>
<?php

    echo "<tr><td>".$row[0]."</td><td>".$row[1]."</td><td>".$row[2]."</td><td>".$row[3]."</td><td>".$row[4]."</td><td>".$row[5]."</td><td>".$row[6]."</td><td>".$row[7]."</td></tr>";
}
else{
    echo"<br> Employee Not Found of '$eid'";
}
?>
</body>
</html>