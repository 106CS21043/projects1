<html>
    <body>

        <?php
     
        
        $con=mysql_connect("localhost","root","");
        mysql_select_db("flight",$con);
        $records=mysql_query("select * from routes");
       
?>
<div class="border">
<table border=2>
    <tr><th>f_id</th><th>source</th><th>destination</th><th>date</th><th>depart_time</th>
    <th>arrival_time</th><th>duration</th><th>no_of_seats</th><th>booked seats</th><th> available seats</th><th>price</th></tr>
    <?php
     while($row=mysql_fetch_array($records))
     { 

        echo"<tr><td>".$row[0]."</td><td>".$row[1]."</td><td>".$row[2]."</td><td>".$row[3]."</td><td>".$row[4]."</td><td>".$row[5]."</td><td>".$row[6]."</td><td>".$row[7]."</td><td>".$row[8]."</td><td>".$row[9]."</td><td>".$row[10]."</td></tr>";
    }
    
    ?>
    </div>
<a href="usermain.html">home</a>
    </body>
    </html>
