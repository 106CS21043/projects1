<!DOCTYPE html>
<html>
<head>
    <title>Update Flight details</title>
</head>
<body>
    <center>
        <h1>Update Flight details</h1>
        <hr>
        <?php
        $fno = $_POST['f_id'];
        $con = mysqli_connect("localhost", "root", "", "flight");
        $query = "SELECT * FROM flights WHERE f_no = ?";
        $stmt = mysqli_prepare($con, $query);
        mysqli_stmt_bind_param($stmt, "s", $fno);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        if ($row = mysqli_fetch_array($result)) {
        ?>
            <form method="post" action="flightupdatesave.php">
                <table>
                    <tr height="40px">
                        <td>Flight Name</td>
                        <td><input type="text" name="f_name" value="<?php echo $row[0]; ?>"></td>
                    </tr>
                    <tr height="40px">
                        <td>Flight Number</td>
                        <td><input type="text" name="f_no" value="<?php echo $row[1]; ?>"></td>
                    </tr>
                    <tr height="40px">
                        <td>Flight Type</td>
                        <td>
                        <select name="f_type">
    <option value=""> </option>
    <option <?php if($row['f_type'] == 'commercial flight') echo 'selected'; ?>>commercial flight</option>
    <option <?php if($row['f_type'] == 'Domestic flight') echo 'selected'; ?>>Domestic flight</option>
    <option <?php if($row['f_type'] == 'International flight') echo 'selected'; ?>>International flight</option>
    <option <?php if($row['f_type'] == 'First class') echo 'selected'; ?>>First class</option>
</select>


                        </td>
                    </tr>
                    <tr>
                        <td><input type="submit" value="UPDATE"></td>
                    </tr>
                </table>
            </form>
        <?php
        } else {
            echo "<br><br>No Flights found by Id '$fno' ....";
        }
        ?>
    </center>
</body>
</html>