

<?php
include 'content.php';
?>

    <div  class="border" style="height:200px;">
       
        
      <h2 >Delete Employee </h2><hr>
      
          <form method="post"action="empdeletesearch.php">
          Enter your id:<input type="text" name="eid"><br><br>
          <input type="submit" value="delete records">
          </form>
      
 </form></div>