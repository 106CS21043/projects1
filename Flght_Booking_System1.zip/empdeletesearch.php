<!DOCTYPE html>
    <html lang="en">
    <head>
        
        <title> Admin Main page</title>
        <link rel="stylesheet" href="Alladmin.css">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    </head>
    <body>
    <nav class="navbar navbar-expand-lg" id="navbar">
        <div class="container">
          <a class="navbar-brand" href="" id="logo"><span>ST</span>airlines</a>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mynavbar">
            <span><i class="fa-solid fa-bars"></i></span>
          </button>
          <div class="collapse navbar-collapse" id="mynavbar">
            <ul class="navbar-nav me-auto">
              <li class="nav-item">
                <a class="nav-link active" href="home.html">Home</a>
              </li>
              <li class="nav-item">
                <div class="dropdown">
                  <button class="dropbtn">Employee</button>
                  <div class="dropdown-content">
                    <a href="emp.html">add Employee</a>
                    <a href="empupdate.html">update Employee</a>
                    <a href="empdelete.html">delete Employee</a>
                    <a href="searchempid.html">Search Employee</a>
                   <a href="empsearchlist.php">view Employees</a>
                  </div>
                </div>
              </li>
              <li class="nav-item">
                <div class="dropdown">
                  <button class="dropbtn">Flights</button>
                  <div class="dropdown-content">
                    <a href="flights.html">add Flights</a>
                    <a href="flightupdate.html">update Flights</a>
                    <a href="flightdelete.html">delete Flights</a>
                    <a href="flightsearchid.php">Search Flights</a>
                    <a href="flightserachlist.php">view Flights</a>
                  </div>
                </div>
              </li>
              <li class="nav-item">
                <div class="dropdown">
                  <button class="dropbtn">ADMIN</button>
                  <div class="dropdown-content">
                    <a href="main.html">LOG OUT</a>
                    </div>
                </div>
              </li>
            </ul>
            
          </div>
        </div>
      </nav>
      <center>
      <header class="section__container header__container">
       
        <img src="header.jpg" alt="header" style="filter: blur(5px);" /><br><br>
      </header>
      
       
<?php
$eid=$_POST['eid'];
$con=mysql_connect("localhost","root","");
mysql_select_db("flight",$con);
$records=mysql_query("select * from employee where emp_id='$eid'");
if($row=mysql_fetch_array($records)){

?>
<div  class="border">
<form method="post" action="empdeletesave.php">
<center><h1>Delete Data</h1><hr>
    <table>
        <tr height="40px">
            <td width="200px">Enter Employee Name</td>
            <td><input type="text" name="emp_name" value="<?php echo $row[0];?>"></td>
        </tr>
        <tr height="40px">
            <td>Enter Id</td>
            <td><input type="text" name="emp_id"  readonly value="<?php echo $row[1];?>"></td>
        </tr>
        <tr height= "40px">
            <td>Enter DOB</td>
            <td><input type="date" name="emp_dob" value="<?php echo $row[2];?>"></td>
        </tr>
        <tr height= "40px">
            <td>Gender</td>
            <td>MALE<input type="radio" name="emp_gender" value="<?php echo $row[3];?>">FEMALE<input type="radio" name="emp_gender" value="<?php echo $row[3];?>"></td>
        </tr>
        <tr height="40px">
            <td>Enter  JOB TYPE</td >
            <td><input type="text" name="emp_job" value="<?php echo $row[4];?>" ></td>
        </tr>
        <tr height= "40px">
            <td>Enter Salary</td>
            <td><input type="text" name="emp_sal" value="<?php echo $row[5];?>"></td>
        </tr>
        <tr height= "40px">
            <td>Address </td>
            <td><input type="text" name="emp_address" value="<?php echo $row[6];?>" ></td>
        </tr>
        <tr height= "40px">
            <td>Enter Contact-No</td>
            <td><input type="text" name="emp_mob" value="<?php echo $row[7];?>"></td>
        </tr>
        <tr height= "40px" >
            <td><input type="submit" value="Delete Records"></td>
        </tr>
        </table>

<?php
}
else
{
echo"<br><br>No such records found...";
}
?>  
</form>







        
       
      </center>
      <footer class="footer">
        <div class="section__container footer__container">
          <div class="footer__col">
            <h3>Pathway<span>.</span></h3>
            
              Explore your suitable and dream places around the world. Here you
              can find your right destination.
            
          </div>
          <div class="footer__col">
            <h4>Support</h4>
            <p>FAQs</p>
            <p>Terms & Conditions</p>
            <p>Privacy Policy</p>
            <p>Contact Us</p>
          </div>
          <div class="footer__col">
            <h4>Address</h4>
            
              <span>Address:</span> 280 Wilson Street, Cima, California, 92323,
              United States
            
            <span>Email:</span> info@pathway.com <br>
            <span>Phone:</span> +91 9876543210
          </div>
        </div>
      </footer>
    
    </body>
    </html>