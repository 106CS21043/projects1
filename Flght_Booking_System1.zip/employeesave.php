<html>
    <body>
        <?php
        $ename=$_POST['emp_name'];
        $eid=$_POST['emp_id'];
        $edob=$_POST['emp_dob'];
        $egender=$_POST['emp_gender'];
        $ejob=$_POST['emp_job'];
        $esal=$_POST['emp_sal'];
        $eadd=$_POST['emp_address'];
        $emob=$_POST['emp_mob'];
        $con=mysql_connect("localhost","root","");
        mysql_select_db("flight",$con);
        mysql_query("insert into employee values('$ename','$eid','$edob','$egender','$ejob','$esal','$eadd','$emob')");
        echo"<br><center><b>New Employee &nbsp $ename Added Successful....!";
?>
<a href="adminmain.html">home</a>
    </body>
    </html>
