
<?php
  $fid = $_POST['f_id'];
  $con=mysql_connect("localhost","root","");
  mysql_select_db("flight",$con);
  $records=mysql_query("select * from routes where f_id=$fid");
  if($row=mysql_fetch_array($records)) {
  ?>
  <form method="post" action="travellersdetailsave1.php">
 <div  class="border">
        <h2 > Flight details</h2><hr>  
<table  >
        <tr height="50px">
            <td width="200px">Flight id</td>
            <td><input type="text" name="fid" readonly value="<?php echo $row[0]; ?>"></td>
        </tr>           
        <tr height="50px">
            <td> Source</td>
            <td><input type="text" name="fsrc" readonly value="<?php echo $row[1]; ?>"></td>
        </tr>
        <tr height= "50px">
            <td> Destination</td>
            <td><input type="text" name="fdstn" readonly value="<?php echo $row[2]; ?>"></td>
       </tr>
       <tr height="40px">
        <td>  Date</td >
        <td><input type="date" name="date"  readonly value="<?php echo $row[3]; ?>"></td>
    </tr>
        <tr height="40px">
            <td>  Depart time</td >
            <td><input type="text" name="departtime"  readonly value="<?php echo $row[4]; ?>"></td>
        </tr>
        
        <tr height= "40px">
            <td> Arrival time</td>
            <td><input type="text" name="arrivaltime" readonly value="<?php echo $row[5]; ?>"></td>
        </tr>
        <tr height= "40px">
            <td> Duration </td>
            <td><input type="text" name="fduration"readonly  value="<?php echo $row[6]; ?>"td>
        </tr>
        <tr height= "40px">
          <td> No of seats </td>
          <td><input type="text" name="fseats" readonly value="<?php echo $row[7]; ?>"></td>
      </tr>
      <tr height= "40px">
        <td>  No of seats booked</td>
        <td><input type="text" name="bookedseats" readonly value="<?php echo $row[8] ?>"></td>
    </tr>
      
      <tr height= "40px">
        <td>  Seats Available   </td>
        <td><input type="text" name="availableseats" readonly value="<?php echo $row[9]?>"></td>
    </tr>
        <tr height= "40px">
            <td> price</td>
            <td><input type="text" name="fprice" readonly value="<?php echo $row[10]; ?>"></td>
        </tr>
      </table>
      
        
</div>


<div class="border">
<h2> Traveller details</h2><hr>

            <table border=0 width=400>
                <tr height=40>
                <td>Name : </td>
                <td> <input type="text" name="pname" class="input" size=20 placeholder="Enter your name" autofocus> </td>
                </tr>
                <tr height=40>
                    <td>Passport Id  : </td>
                    <td> <input type="text" name="passportid" class="input" size=20 placeholder="Enter your passport id"> </td>
                    </tr>
                    <tr height=40>
                    <td> Nationality : </td>
                    <td> <input type="text" name="nationality" class="input" size=20 placeholder="Enter your nationaliy"> </td>
                    </tr>
                
                
                <tr height=40>
                <td>Gender :</td>
                <td> <input type="radio" name="pgender" value="male">Male
                 <input type="radio" name="pgender" value="Female">Female</td> 
                </tr>
                <tr height=40>
                <td>Date of Birth : </td>
                <td> <input type="date" name="pdob" class="input"> </td>
                </tr><br>
                <tr height=40>
                  <td>Age :</td>
                  <td> <input type="text" name="age" class="input" placeholder="Enter your Age"> </td>
                  </tr>
                  <tr height=40>
                    <td>Email-Id:</td>
                    <td> <input type="email" name="pemail" class="input" placeholder="Enter your email"> </td>
                    </tr>
                  <tr height=40>
                    <td>Phone no :</td>
                    <td> <input type="text" name="phoneno" class="input" placeholder="Enter your contactno"> </td>
                    </tr>
                <tr height=40>
                <td>Address :</td>
                <td><input type="text" name="paddress"></td>
                </tr>
                <tr height=40>
                <td>No of Passenger</td>
                <td><input type="number"  name="noofpass"></td>
                </tr>
                
            </table><br>
            <button class="button" type="reset" value="reset"><span class="button-content">Reset</span></button>
	          <button class="button" type="submit" value="submit"><span class="button-content"> Book ticket </span></button><br><br>
          </div> 
        </form>

<?php


} else {
   
    header("Location: usermain.html");
    exit(); 
}
?>








