<html>
    <body>
        <?php
        $fname=$_POST['f_name'];
        $fno=$_POST['f_no'];
     
        $ftype=$_POST['f_type'];
     
  
        
        $con=mysql_connect("localhost","root","");
        mysql_select_db("flight",$con);
        mysql_query("Update flights set f_name='$fname',f_type='$ftype' where f_no='$fno' ");
        echo"<br><center><b> Flight &nbsp $fname Updated  Successful....!";
?>
<a href="adminmain.html">home</a>
    </body>
    </html>